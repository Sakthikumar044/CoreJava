package day15;

import java.util.Scanner;

abstract class Calculator{
	
	public abstract void add(int a , int b);
	public abstract void sub(int a , int b);
	public abstract void mul(int a , int b);
	public abstract void div(int a , int b);
	
	public  void modules(int a , int b) {
		System.out.println("Modules : "+(a%b));
	}
	
}


public class AbstractEX extends Calculator {
	
	public void add(int a,int b) {
		System.out.println("Addition : "+(a+b));
	}
	
	public void sub(int a,int b) {
		System.out.println("Subraction : "+(a-b));
	}
	
	public void mul(int a,int b) {
		System.out.println("Multiplication : "+(a*b));
	}
	
	public void div(int a,int b) {
		System.out.println("Divsion : "+(a/b));
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the  value a :");
		int a = sc.nextInt(); 
		System.out.println("Enter the  value b :");
		int b = sc.nextInt(); 
		
		
		
		AbstractEX calc = new AbstractEX();
		calc.add(a, b);
		calc.sub(a, b);
		calc.mul(a, b);
		calc.div(a, b);
		calc.modules(a, b);
		
	}

}
