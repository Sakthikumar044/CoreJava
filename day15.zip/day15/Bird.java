package day15;

public class Bird implements Animal{
	
	public void move() {
		System.out.println("The bird flies in the sky.");
		
	}
	public void speak() {
		System.out.println("The bird says : Chirp Chrip!");
	}

}
