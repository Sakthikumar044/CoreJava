package day15;

public interface Animal {
	
	String Category = "Living Being";
	
	static boolean isMammual(String animalName) {
		return animalName == "Dog" || animalName == "Cat" || animalName == "Human";
		
	}
	
	default void speak() {
		System.out.println("Animal is making sound.");		
	}
	
	void move();

}
