package day15;

public class TestClass {
	public static void main(String[] args) {
		Dog d = new Dog();
		Bird b = new Bird();
		
		System.out.println("Dog");
		d.move();
		d.speak();
		
		System.out.println("Bird");
		b.move();
		b.speak();
		
		System.out.println(Animal.isMammual("Dog"));
		System.out.println(Animal.isMammual("Bird"));
		System.out.println(Animal.Category);
	}

}
