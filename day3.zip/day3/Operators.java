package day3;

public class Operators {
	public static void main(String[] args) {
		
		int num1 = 12;
		int num2 = 25;
		int num3 = 10;
		int num4 = 50;
		int num5 = 100;
		int num6 = 5;

		
	
	
		
		//Arithmetic Operation
		
		System.out.println("Arithmetic Operation:");
		System.out.println("Addition : " +(num1 + num2));
		System.out.println("Subtraction :" +(num1 - num2));
		System.out.println("Multiplicatin : "+(num1 * num2));
		System.out.println("Division : "+(num1 / num2));
		System.out.println("Modulus : "+(num1 % num2));
		
		System.out.println("\nRelational Operations:");
		System.out.println(num1 +" > "+num2 +" : "+(num1>num2));
		System.out.println(num1 +" < "+num2+" : "+(num1<num2));
		System.out.println(num1 +" >= "+num2+" : "+(num1>=num2));
		System.out.println(num1 +" <= "+num2+" : "+(num1<=num2));
		System.out.println(num1 +" == "+num2+" : "+(num1==num2));
		System.out.println(num1 +" != "+num2+" : "+(num1!=num2));
		
		System.out.println("\nLogical Operations:");
		System.out.println("("+num1 +" > "+num3 +" AND "+num2+" < "+num4+")"+" : " +(num1>num3 && num2 <num4));
		System.out.println("("+num1 +" < "+num6 +" AND "+num2+" < "+num5+")"+" : " +(num1>num6 && num2 <num5));
		
		
		System.out.println("\nAssignment Operations:");
		System.out.println("Intial value: "+num3);
		System.out.println("After += : "+ (num1 += num3));
		System.out.println("After -= : "+ (num1 -= num3));
		System.out.println("After *= : "+ (num1 *= num3));
		System.out.println("After /= : "+ (num1 /= num3));
		System.out.println("After %= : "+ (num1 %= num3));
		
		System.out.println("\nUnary Operations:");
		System.out.println("Intial value: "+num1);
		System.out.println("After increament: "+(++num1));
		System.out.println("After decrement: "+(--num1));
		
		
	}

}
