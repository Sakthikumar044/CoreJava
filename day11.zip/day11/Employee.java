package day11;


public class Employee {
	
	int id;
	String name;
	long phoneNo;
	int salary;
	
	void display() {
		System.out.println("Employee ID :"+id);
		System.out.println("Employee Name :"+name);
		System.out.println("Employee Phone No :"+phoneNo);
		System.out.println("Employee Salary :"+salary);
		
				
	}

}
