package day11;

public class UserInterface {
	
public static void main(String[] args) {
		
		Employee emp1 = new Employee();
		emp1.id = 2001;
		emp1.name ="Ajay";
		emp1.phoneNo = 9234567832l;
		emp1.salary = 50000;
		
		emp1.display();
		
		Employee emp2 = new Employee();
		emp2.id = 2101;
		emp2.name = "Arun";
		emp2.phoneNo = 9234567456l;
		emp2.salary = 55000;
		emp2.display();
		
		
		
		Employee emp3 = new Employee();
		emp3.id = 2131;
		emp3.name = "Deepak";
		emp3.phoneNo = 9234567844l;
		emp3.salary = 40000;
		emp3.display();
		
		
		
		
		Employee emp4 = new Employee();
		emp4.id = 2231;
		emp4.name = "Raja";
		emp4.phoneNo = 9234567362l;
		emp4.salary = 70000;
		emp4.display();
		
		

}
}
