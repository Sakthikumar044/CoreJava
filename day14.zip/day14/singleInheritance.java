package day14;


class animalEx{
	
	void display() {
		
		System.out.println("This is an Animal");
		
	}
	
	void sentence() {
		System.out.println("This is an Animal");
	}
}

class DOG extends animal{
	
	void display() {
		System.out.println("This is an dog ");
	}
}

public class singleInheritance {
	public static void main(String[] args) {
		
		dog d = new dog();
		d.display();
		d.sentence();
	}
	

}
