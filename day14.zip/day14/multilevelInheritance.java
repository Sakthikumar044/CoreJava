package day14;

class animal{
	
	void display() {
		
		System.out.println("This is an Animal");
		
	}
	
	void sentence() {
		System.out.println("This is an Animal");
	}
}

class dog extends animal{
	
	void display() {
		System.out.println("This is an dog ");
	}
}


class Puppy extends dog{
	void display() {
		System.out.println("This is an puppy");
	}
}



public class multilevelInheritance {
	
	public static void main(String[] args) {
		
		Puppy a = new Puppy();
		a.display();
		a.sentence();
		
	}

}
