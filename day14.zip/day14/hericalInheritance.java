package day14;
class animal1{
	
	void display() {
		
		System.out.println("This is an Animal");
		
	}
	
	void sentence() {
		System.out.println("This is an Animal");
	}
}

class dog1 extends animal{
	
	void display() {
		System.out.println("This is an dog ");
	}
}

class cat extends animal {
	
	void display() {
		System.out.println("This is an cat");
	}
}



public class hericalInheritance {
	public static void main(String[] args) {
		
		cat c = new cat();
		c.display();
		c.sentence();

	}

}
