package day8;

import java.util.Scanner;

public class ReverseString {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the word :");
		String word = sc.next();
		String a = word.trim();
		String rs= "";
		for(int i = a.length()-1; i>=0; i--) {
			rs = rs+a.charAt(i);
		}
		System.out.println(rs);
		if(a.equals(rs)) {
			System.out.println("Palimdrome ");
		}
		else {
			System.out.println("Not a Palimdrome");
		}
	}

}
