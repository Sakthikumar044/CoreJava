package day9;

import java.util.Scanner;

public class WhileLoop {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean isTrue =true;
		while(isTrue){
			System.out.println("Enter your choice :");
			System.out.println("1 :Add \n2 : Sub \n3 : Multiplication \n4 : Division \n5 : Modules \n0 : Exit");
			
			int key = sc.nextInt();
			
			switch(key) {
			case 1 :
			{
				System.out.println("Enter the num 1 :");
				int num1 = sc.nextInt();
				System.out.println("Enter the num 2 :");
				int num2 = sc.nextInt();
				System.out.println("Addition : "+(num1 + num2));
				break;
				
			}
			case 2 :
			{
				System.out.println("Enter the num 1 :");
				int num1 = sc.nextInt();
				System.out.println("Enter the num 2 :");
				int num2 = sc.nextInt();
				System.out.println("Subraction : "+(num1 - num2));
				break;
				
			}
			case 3 :
			{
				System.out.println("Enter the num 1 :");
				int num1 = sc.nextInt();
				System.out.println("Enter the num 2 :");
				int num2 = sc.nextInt();
				System.out.println("Multiplication : "+(num1 * num2));
				break;
				
			}
			case 4 :
			{
				System.out.println("Enter the num 1 :");
				int num1 = sc.nextInt();
				System.out.println("Enter the num 2 :");
				int num2 = sc.nextInt();
				System.out.println("Division : "+(num1 / num2));
				break;
				
			}
			case 5 :
			{
				System.out.println("Enter the num 1 :");
				int num1 = sc.nextInt();
				System.out.println("Enter the num 2 :");
				int num2 = sc.nextInt();
				System.out.println("Modules : "+(num1 % num2));
				break;
				
			}
			case 0:
			{
				isTrue = false;
				System.out.println("Thank You");
				break;
			}
			default :
			{
				System.out.println("Enter the correct choice!");
			}
			}
		}
		
	}


}
