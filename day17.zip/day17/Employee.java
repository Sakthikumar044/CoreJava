package day17;

public class Employee {
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", phoneNo=" + phoneNo + ", salary=" + salary + "]";
	}
	private int id;
	private String name;
	private long phoneNo;
	private int salary;
	public Employee() {
		super();
	}
	public Employee(int id, String name, long phoneNo, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNo = phoneNo;
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	

}
