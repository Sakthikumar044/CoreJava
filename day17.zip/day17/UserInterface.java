package day17;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Employee em = new Employee();
		ArrayList<Employee> al = new ArrayList<>();
		boolean istrue= true;
		while(istrue){
			System.out.println("Enter 1 to add the Employee");
			System.out.println("Enter 2 to show the Employee");
			System.out.println("Enter 3 to modify the Employee");
			System.out.println("Enter 4 to delete the Employee");
			
			int key = sc.nextInt();
			
			if(key==1) {
				System.out.println("Enter the Employee ID :");
				int id=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the Employee Name :");
				String name=sc.nextLine();
				System.out.println("Enter the Employee Phone No :");
				long phoneNo = sc.nextLong();
				System.out.println("Enter the Employee Salary :");
				int salary=sc.nextInt();
				
				em = new Employee(id ,name ,phoneNo ,salary);
				al.add(em);
							
			}
			else if(key==2) {
				System.out.println(al);
				
				
			}
			else if(key==3) {
				System.out.println("Enter the Employee Id :");
				int id= sc.nextInt();
				
				
				for(Employee c : al) {
					if(id==c.getId()) {
						System.out.println("Set a id");
						int empid=sc.nextInt();
						sc.nextLine();
						System.out.println("set a Name");
						String empname=sc.nextLine();
						System.out.println("set a Phone No");
						long empnumber=sc.nextLong();
						System.out.println("set a Salary");
						int empsalary=sc.nextInt();
						
						c.setId(empid);
						c.setName(empname);
						c.setPhoneNo(empnumber);
						c.setSalary(empsalary);	
					}
			}	
			}
			else if(key==4) {
				
				System.out.println("Select Id for delete a employee");
				int id=sc.nextInt();

				for(Employee c: al) {
					if(id==c.getId()) {
						al.remove(c);
						break;
					}
				}

				
			}
			else {
				 istrue= false;
			}
		}
		
			
		
	}

}











