package day9;

import java.util.Scanner;

public class ArrayEX2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String Para= "A paragraph is a distinct unit of writing, typically composed of multiple sentences, that focuses on a single idea or topic. It serves as a building block for longer pieces of text, helping to organize and structure information for better readability. Paragraphs usually begin with an indentation, and they can contain various types of information, such as examples, descriptions, or narratives. ";
		char[] Letter = Para.toCharArray();
		int count=0;
		System.out.println("Enter the character :");
		String a= sc.next();
		
		for(char ref : Letter) {
			if(ref == 'a') {
				count++;
			}
		}
		System.out.println(count);
		
		
		
	}

}
