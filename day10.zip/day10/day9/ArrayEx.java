package day9;

public class ArrayEx {
	public static void main(String[] args) {
		
		String []arr= new String[5];
		
		arr[0]= "Adarsh";
		arr[1]= "Ajay";
		arr[2]= "Arun";
		arr[3]= "Deepak";
		arr[4]= "Muneef";
		
		for(int i =0; i<arr.length; i++) {
			if(arr[i].equals("Arun")) {
				arr [i]= "Ajith";
			}
		}
		System.out.println("Replaced word :");
		for(String Ref : arr) {
			System.out.println(Ref);
		}
	}

}
