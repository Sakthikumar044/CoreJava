package day9;

public class dowhile {
	public static void main(String[] args) {
		
		boolean istrue= false;
		 do {
			 System.out.println("hello");
		 }while(istrue);
	}

}
