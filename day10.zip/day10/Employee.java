package day10;

import java.util.Scanner;

public class Employee {
	
	int id;
	String name;
	long phoneNo;
	int salary;
	
	public static void main(String[] args) {
		
		Employee emp1 = new Employee();
		emp1.id = 2001;
		emp1.name ="Ajay";
		emp1.phoneNo = 9234567832l;
		emp1.salary = 50000;
		
		System.out.println("Employee1 ID : "+emp1.id);
		System.out.println("Employee1 Name : "+emp1.name);
		System.out.println("Employee1 Phone No : "+emp1.phoneNo);
		System.out.println("Employee1 Salary : "+emp1.salary);
		
		
		Employee emp2 = new Employee();
		emp2.id = 2101;
		emp2.name = "Arun";
		emp2.phoneNo = 9234567456l;
		emp2.salary = 55000;
		
		System.out.println("Employee2 ID : "+emp2.id);
		System.out.println("Employee2 Name : "+emp2.name);
		System.out.println("Employee2 Phone No : "+emp2.phoneNo);
		System.out.println("Employee2 Salary : "+emp2.salary);
		
		
		
		Employee emp3 = new Employee();
		emp3.id = 2131;
		emp3.name = "Deepak";
		emp3.phoneNo = 9234567844l;
		emp3.salary = 40000;
		
		System.out.println("Employee3 ID : "+emp3.id);
		System.out.println("Employee3 Name : "+emp3.name);
		System.out.println("Employee3 Phone No : "+emp3.phoneNo);
		System.out.println("Employee3 Salary : "+emp3.salary);
		
		
		Employee emp4 = new Employee();
		emp4.id = 2231;
		emp4.name = "Raja";
		emp4.phoneNo = 9234567362l;
		emp4.salary = 70000;
		
		System.out.println("Employee4 ID : "+emp4.id);
		System.out.println("Employee4 Name : "+emp4.name);
		System.out.println("Employee4 Phone No : "+emp4.phoneNo);
		System.out.println("Employee4 Salary : "+emp4.salary);
		
		
		Scanner sc = new Scanner(System.in);
		Employee emp5 = new Employee();
		System.out.println("Employee5 ID : ");
		emp5.id = sc.nextInt();
		System.out.println("Employee5 Name : ");
		sc.nextLine();
		emp5.name = sc.nextLine();
		System.out.println("Employee5 Phone No : ");
		emp5.phoneNo = sc.nextLong();
		System.out.println("Employee5 Salary : ");
		emp5.salary = sc.nextInt();
		
		System.out.println("Employee5 ID : "+emp5.id);
		System.out.println("Employee5 Name : "+emp5.name);
		System.out.println("Employee5 Phone No : "+emp5.phoneNo);
		System.out.println("Employee5 Salary : "+emp5.salary);

		
		
	}
	

}
