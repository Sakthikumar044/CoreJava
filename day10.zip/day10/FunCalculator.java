package day10;

import java.util.Scanner;

public class FunCalculator {
	
	public void add(int num1, int num2) {
		System.out.println("Addition : "+(num1 + num2));
	}
	
	public void sub(int num1, int num2) {
		System.out.println("Subraction : "+(num1 - num2));
	}
	
	public void multipication(int num1, int num2) {
		System.out.println("Multiplication : "+(num1 * num2));
	}
	
	public void division(int num1, int num2) {
		System.out.println("Division : "+(num1 / num2));
	}
	
	public void modules(int num1, int num2) {
		System.out.println("Modules : "+(num1 % num2));
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		FunCalculator calc = new FunCalculator();
		System.out.println("Enter the Number 1 : ");
		int num1 = sc.nextInt();
		System.out.println("Enter the Number 2 : ");
		int num2 = sc.nextInt();
		
		calc.add(num1, num2);
		calc.sub(num1, num2);
		calc.multipication(num1, num2);
		calc.division(num1, num2);
		calc.modules(num1, num2);
		
	}

}
